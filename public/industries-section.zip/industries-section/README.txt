INDUSTRIES SECTION

Files:
- Industries.jsx
- industries.css
- public/images/industries/*.jpg (cropped product image assets from the supplied design reference)

Setup:
1. Copy Industries.jsx and industries.css into the same component folder.
2. Copy the included public folder into your Next.js project's root (merge with your existing public folder).
3. Install lucide-react if it is not already installed: pnpm add lucide-react
4. Import and render the component: import Industries from "@/components/Industries"; then use <Industries />.

Animation:
- Heading and cards reveal when they enter the viewport.
- Cards stagger in sequence.
- Hover adds a subtle lift, image zoom and icon interaction.
- Respects prefers-reduced-motion.

The CSS is component-scoped; it does not require replacing your existing global.css.
