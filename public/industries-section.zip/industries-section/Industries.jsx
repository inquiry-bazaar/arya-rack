"use client";

import { useEffect, useRef } from "react";
import { Layers3, PanelsTopLeft, Box, ShoppingBasket, ArrowUpRight } from "lucide-react";
import "./industries.css";

const industries = [
  {
    title: "Wall Rack",
    description: "Durable wall-mounted shelving designed to keep products organised and easy to access.",
    image: "/images/industries/wall-rack.jpg",
    icon: PanelsTopLeft,
    alt: "Wall-mounted retail shelving",
  },
  {
    title: "Corner Rack",
    description: "Smart, space-saving corner displays that make every inch of your store count.",
    image: "/images/industries/corner-rack.jpg",
    icon: Box,
    alt: "Corner retail rack shelving",
  },
  {
    title: "Gondolas",
    description: "Versatile freestanding display systems for supermarkets, retail chains and showrooms.",
    image: "/images/industries/gondolas.jpg",
    icon: Layers3,
    alt: "Freestanding gondola display shelving",
  },
  {
    title: "Fruits & Vegetable Rack",
    description: "Fresh-produce displays designed for clear visibility, neat presentation and easy browsing.",
    image: "/images/industries/fruits-vegetable-rack.jpg",
    icon: ShoppingBasket,
    alt: "Fresh fruit and vegetable display rack",
  },
];

export default function Industries() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const items = section.querySelectorAll("[data-reveal]");
    if (!("IntersectionObserver" in window)) {
      items.forEach((item) => item.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver(
      (entries, currentObserver) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            currentObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -45px 0px" }
    );

    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  return (
    <section className="industries-section" ref={sectionRef} aria-labelledby="industries-heading">
      <div className="industries-bg-glow industries-bg-glow--left" aria-hidden="true" />
      <div className="industries-bg-glow industries-bg-glow--right" aria-hidden="true" />

      <div className="industries-container">
        <header className="industries-heading" data-reveal>
          <div className="industries-eyebrow">
            <span />
            <p>Industries We Serve</p>
            <span />
          </div>
          <h2 id="industries-heading">
            Retail Solutions for <em>Every Industry</em>
          </h2>
          <p className="industries-intro">
            Versatile, durable, and space-efficient racking systems designed to meet the
            unique needs of retail and commercial spaces.
          </p>
        </header>

        <div className="industries-grid">
          {industries.map((item, index) => {
            const Icon = item.icon;
            return (
              <article
                className="industry-card"
                data-reveal
                style={{ "--card-index": index }}
                key={item.title}
              >
                <div className="industry-card__image-wrap">
                  <img src={item.image} alt={item.alt} loading="lazy" />
                  <div className="industry-card__image-shade" />
                </div>
                <div className="industry-card__icon" aria-hidden="true">
                  <Icon size={27} strokeWidth={1.7} />
                </div>
                <div className="industry-card__content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <div className="industry-card__bottom-line">
                    <span />
                    <ArrowUpRight size={18} strokeWidth={2} aria-hidden="true" />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
